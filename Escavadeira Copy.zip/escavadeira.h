#pragma once
// Escavadeira ESP32 - casca de hardware. Toda a logica fica em lib/EscavCore.
#include <Arduino.h>
#include <Preferences.h>
// ---- Controller.h
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
// ---- Hal.h
#include <stddef.h>
// ---- Config.h
#include <stdint.h>
// Medidas e limites vindos do modelo Fusion "Escavadeira" (mm e graus).
namespace escav {

enum Joint : uint8_t { SLEW = 0, BOOM, STICK, BUCKET, N_JOINTS };
enum Wheel : uint8_t { FL = 0, FR, RL, RR, N_WHEELS };
constexpr int N_SERVOS = N_JOINTS + N_WHEELS;   // 0..3 juntas, 4..7 rodas

struct JointSpec { const char* name; float min, max, center, maxSpeed, maxAccel; };
// center = angulo da junta com o servo em 1500 us
constexpr JointSpec JOINTS[N_JOINTS] = {
  {"giro",    -90.f,  90.f,   0.f,  80.f, 200.f},
  {"lanca",   -85.f,  50.f, -17.5f, 45.f, 140.f},
  {"braco",  -130.f,  35.f, -47.5f, 70.f, 220.f},
  {"cacamba", -90.f,  90.f,   0.f, 110.f, 360.f},
};

constexpr uint32_t CONFIG_MAGIC = 0x45534356;   // "ESCV"
constexpr uint16_t CONFIG_VERSION = 1;

struct Settings {
  uint32_t magic = CONFIG_MAGIC;
  uint16_t version = CONFIG_VERSION;
  int16_t trimUs[N_SERVOS] = {0,0,0,0,0,0,0,0};
  int8_t  dir[N_SERVOS]    = {1,1,1,1, 1,-1,1,-1};   // rodas direitas giram ao contrario
  float   usPerDeg = 10.56f;                          // SG90: 1900 us em 180 graus
  uint8_t driveMax = 100;        // % da velocidade das rodas
  uint8_t armMax = 100;          // % da velocidade do braco
  uint8_t driveDeadbandUs = 30;  // zona morta do servo 360
  uint8_t guard = 1;             // anticolisao
  uint16_t lowMv = 6600;         // aviso de bateria
  uint16_t cutMv = 6200;         // corte de bateria (2S)
  uint16_t adcCal = 1000;        // calibracao da bateria, por mil
  char name[17] = "Escavadeira";
};

constexpr int   SERVO_MID_US = 1500, SERVO_MIN_US = 500, SERVO_MAX_US = 2500;
constexpr int   WHEEL_SPAN_US = 500;     // +-500 us = velocidade maxima do servo 360
constexpr uint32_t LINK_TIMEOUT_MS = 600;
constexpr uint32_t SEQ_SLOTS = 3, SEQ_MAX = 24;

struct Pose { float q[N_JOINTS]; };
struct Preset { const char* name; Pose p; };
constexpr int N_PRESETS = 6;
constexpr Preset PRESETS[N_PRESETS] = {
  {"Transporte", {{0.f, -35.f,   0.f,   0.f}}},
  {"Trabalho",   {{0.f, -20.f, -35.f, -20.f}}},
  {"Cavar",      {{0.f,  30.f, -80.f,   0.f}}},
  {"Carregar",   {{0.f, -35.f, -35.f,  50.f}}},
  {"Despejar",   {{0.f, -35.f, -70.f, -60.f}}},
  {"Alcance",    {{0.f,  36.f, -126.f,  0.f}}},
};
}  // namespace escav

namespace escav {
struct Sequence { uint8_t n = 0; struct Key { int16_t q[N_JOINTS]; uint16_t holdMs; } k[SEQ_MAX]; };
// Tudo que o nucleo precisa do hardware.
struct Hal {
  virtual ~Hal() {}
  virtual void servo(int idx, int us) = 0;          // us = 0 desliga o pulso
  virtual uint32_t batteryMv() = 0;                 // na bateria, ja corrigido pelo divisor
  virtual void send(const char* line) = 0;          // uma linha, sem \n
  virtual bool load(const char* key, void* dst, size_t n) = 0;
  virtual bool save(const char* key, const void* src, size_t n) = 0;
};
}  // namespace escav

// ---- Kinematics.h
#include <math.h>
// Cinematica direta e anticolisao 2D (plano do braco) + giro da torre.
// Convencao do CAD: rotacao positiva em +Y leva +Z para +X (lanca positiva = desce).
namespace escav {

struct V2 { float x, z; };
constexpr float DEG = 0.017453292519943295f;
inline V2 rot(V2 p, float deg) { float c = cosf(deg * DEG), s = sinf(deg * DEG); return {p.x * c + p.z * s, -p.x * s + p.z * c}; }
inline V2 operator+(V2 a, V2 b) { return {a.x + b.x, a.z + b.z}; }

constexpr V2 PIVOT_A{30.f, 94.f};      // pivo da lanca (torre)
constexpr V2 LINK_BOOM{75.f, 55.f};    // A -> T
constexpr V2 LINK_STICK{0.f, -72.f};   // T -> K

struct Frames { V2 t, k; float rb, rs, rk; };
inline Frames forward(const Pose& p) {
  Frames f; f.rb = p.q[BOOM]; f.rs = f.rb + p.q[STICK]; f.rk = f.rs + p.q[BUCKET];
  f.t = PIVOT_A + rot(LINK_BOOM, f.rb); f.k = f.t + rot(LINK_STICK, f.rs); return f;
}
inline V2 teeth(const Pose& p) { Frames f = forward(p); return f.k + rot({-33.f, -60.7f}, f.rk); }

struct Poly { V2 p[8]; int n; };
template <int N> inline Poly place(const V2 (&src)[N], V2 o, float r) { Poly q; q.n = N; for (int i = 0; i < N; i++) q.p[i] = o + rot(src[i], r); return q; }
inline Poly boxPoly(float x0, float x1, float z0, float z1) { return Poly{{{x0, z0}, {x1, z0}, {x1, z1}, {x0, z1}}, 4}; }

// true se a distancia entre os convexos for menor que margin (SAT)
inline bool overlap(const Poly& a, const Poly& b, float margin) {
  for (int w = 0; w < 2; w++) {
    const Poly& s = w ? b : a;
    for (int i = 0; i < s.n; i++) {
      V2 e{s.p[(i + 1) % s.n].x - s.p[i].x, s.p[(i + 1) % s.n].z - s.p[i].z};
      float l = sqrtf(e.x * e.x + e.z * e.z); if (l < 1e-4f) continue;
      float nx = -e.z / l, nz = e.x / l, a0 = 1e9f, a1 = -1e9f, b0 = 1e9f, b1 = -1e9f;
      for (int k = 0; k < a.n; k++) { float d = a.p[k].x * nx + a.p[k].z * nz; a0 = fminf(a0, d); a1 = fmaxf(a1, d); }
      for (int k = 0; k < b.n; k++) { float d = b.p[k].x * nx + b.p[k].z * nz; b0 = fminf(b0, d); b1 = fmaxf(b1, d); }
      if (a1 + margin <= b0 || b1 + margin <= a0) return false;
    }
  }
  return true;
}

// intervalo de x da parte do poligono abaixo de z
inline bool below(const Poly& a, float z, float& x0, float& x1) {
  x0 = 1e9f; x1 = -1e9f;
  for (int i = 0; i < a.n; i++) {
    V2 p = a.p[i], q = a.p[(i + 1) % a.n];
    if (p.z <= z) { x0 = fminf(x0, p.x); x1 = fmaxf(x1, p.x); }
    if ((p.z < z) != (q.z < z)) { float t = (z - p.z) / (q.z - p.z), x = p.x + t * (q.x - p.x); x0 = fminf(x0, x); x1 = fmaxf(x1, x); }
  }
  return x1 >= x0;
}

enum Hit : uint8_t { HIT_NONE = 0, HIT_CHASSIS, HIT_WHEEL, HIT_TURRET, HIT_BOOM };
inline const char* hitName(uint8_t h) { const char* n[] = {"ok", "chassi", "roda", "torre", "lanca"}; return n[h > 4 ? 0 : h]; }

constexpr float ARM_HALF = 24.f;   // meia largura da cacamba
// retangulo do braco [x0,x1]x[-24,24] girado por slew contra retangulo fixo do chassi
inline bool stripHits(float x0, float x1, float slew, float rx0, float rx1, float ry0, float ry1, float m) {
  float c = cosf(slew * DEG), s = sinf(slew * DEG);
  Poly a; a.n = 4; const float X[4] = {x0, x1, x1, x0}, Y[4] = {-ARM_HALF, -ARM_HALF, ARM_HALF, ARM_HALF};
  for (int i = 0; i < 4; i++) a.p[i] = {X[i] * c - Y[i] * s, X[i] * s + Y[i] * c};
  return overlap(a, boxPoly(rx0, rx1, ry0, ry1), m);
}

inline uint8_t checkPose(const Pose& p, float m) {
  static const V2 BK[] = {{-10, -22}, {-33, -60.7f}, {-24, -60}, {15, -56}, {25, -44}, {24, -32}, {12, -22}};
  static const V2 EAR[] = {{-9.5f, -23}, {11.5f, -23}, {10, 9}, {-10, 9}};
  static const V2 ST[] = {{-12, 11}, {-12, -89}, {12, -89}, {12, 11}};
  static const V2 BM[] = {{8.5f, -7}, {49.4f, 43}, {45, 67}, {36.1f, 61.5f}, {-8.5f, 7}};
  static const V2 TIP[] = {{44, 43}, {88, 43}, {92, 47}, {92, 63}, {88, 67}, {44, 67}};
  Frames f = forward(p);
  const Poly bk = place(BK, f.k, f.rk), ear = place(EAR, f.k, f.rk), st = place(ST, f.t, f.rs);
  const Poly bm = place(BM, PIVOT_A, f.rb), tip = place(TIP, PIVOT_A, f.rb);
  const Poly* mov[3] = {&bk, &ear, &st};
  const Poly tur[4] = {boxPoly(-66, -19, 60, 106.4f), boxPoly(-19, 14.4f, 60, 92.4f), boxPoly(14, 46, 60, 64), Poly{{{15, 64}, {45, 64}, {45, 97}, {39, 105}, {21, 105}, {15, 97}}, 6}};
  for (auto* q : mov) for (auto& t : tur) if (overlap(*q, t, m)) return HIT_TURRET;
  for (auto* q : mov) {
    float x0, x1;
    if (below(*q, 46.f + m, x0, x1) && stripHits(x0, x1, p.q[SLEW], -68, 68, -42, 42, m)) return HIT_CHASSIS;
    if (below(*q, 60.f + m, x0, x1) && stripHits(x0, x1, p.q[SLEW], -33, 33, -33, 33, m)) return HIT_CHASSIS;
    if (below(*q, 54.f + m, x0, x1))
      for (int i = 0; i < 4; i++) {
        float wx = (i & 1) ? 21.f : -75.f, wy = (i & 2) ? 46.f : -68.f;
        if (stripHits(x0, x1, p.q[SLEW], wx, wx + 54.f, wy, wy + 22.f, m)) return HIT_WHEEL;
      }
  }
  if (overlap(bk, bm, m) || overlap(bk, tip, m) || overlap(ear, bm, m) || overlap(ear, tip, m)) return HIT_BOOM;
  return HIT_NONE;
}
}  // namespace escav

// ---- Motion.h
#include <math.h>
namespace escav {
inline float clampf(float v, float a, float b) { return v < a ? a : (v > b ? b : v); }

// Eixo com limite de velocidade e aceleracao: modo taxa (joystick) ou posicao.
struct Axis {
  float q = 0, v = 0, target = 0, rate = 0; bool position = true;
  void reset(float a) { q = target = a; v = rate = 0; position = true; }
  void setRate(float r) { position = false; rate = r; }
  void setTarget(float t) { position = true; target = t; }
  void hold() { position = true; target = q; v = 0; rate = 0; }
  float next(const JointSpec& s, float scale, float dt, float& vout) const {
    const float vm = s.maxSpeed * scale, am = s.maxAccel * scale, h = am * dt * 0.5f; float want;
    auto brake = [&](float d) { return d <= 0 ? 0.f : sqrtf(h * h + 2.f * am * d) - h; };   // perfil discreto: para sem tranco
    if (position) {
      float e = target - q, d = fabsf(e);
      want = (e > 0 ? 1.f : -1.f) * fminf(vm, brake(d));
      if (d < 0.05f && fabsf(v) < am * dt) { vout = 0; return target; }
      if (fabsf(want) * dt > d) want = e / dt;
    } else {
      want = clampf(rate, -1.f, 1.f) * vm;
      float room = want > 0 ? s.max - q : q - s.min; if (room < 0) room = 0;
      float cap = brake(room); want = clampf(want, -cap, cap);
    }
    vout = v + clampf(want - v, -am * dt, am * dt);
    float n = q + vout * dt;
    if (position && ((target - q) * (target - n) < 0)) { vout = 0; return target; }
    if (n < s.min) { n = s.min; vout = 0; }
    if (n > s.max) { n = s.max; vout = 0; }
    return n;
  }
};

// Rodas: mistura tanque com rampa. Saida -1..1 por lado.
struct Drive {
  float thr = 0, trn = 0, l = 0, r = 0;
  void set(float t, float n) { thr = clampf(t, -1, 1); trn = clampf(n, -1, 1); }
  void stop() { thr = trn = l = r = 0; }
  void step(float dt, float scale) {
    float a = thr + trn, b = thr - trn, m = fmaxf(1.f, fmaxf(fabsf(a), fabsf(b)));
    a = a / m * scale; b = b / m * scale; const float k = 4.0f * dt;   // 0 a 100% em 250 ms
    l += clampf(a - l, -k, k); r += clampf(b - r, -k, k);
  }
};
inline int wheelUs(float u, const Settings& c, int servo) {
  int mid = SERVO_MID_US + c.trimUs[servo]; if (fabsf(u) < 0.02f) return mid;
  float span = c.driveDeadbandUs + fabsf(u) * (WHEEL_SPAN_US - c.driveDeadbandUs);
  return (int)clampf(mid + (u > 0 ? span : -span) * c.dir[servo], SERVO_MIN_US, SERVO_MAX_US);
}
inline int jointUs(float q, const Settings& c, int j) {
  return (int)lroundf(clampf(SERVO_MID_US + c.trimUs[j] + c.dir[j] * (q - JOINTS[j].center) * c.usPerDeg, SERVO_MIN_US, SERVO_MAX_US));
}
}  // namespace escav

namespace escav {
#define ESCAV_FW "1.0.0"

enum State : uint8_t { DISARMED = 0, ARMED, ESTOP, LOWBAT };
enum Flag : uint16_t { F_LINK = 1, F_BLOCK = 2, F_REC = 4, F_PLAY = 8, F_WARN = 16, F_MOVING = 32, F_DIRTY = 128, F_NOBAT = 256 };

class Controller {
 public:
  explicit Controller(Hal& h) : hal(h) {}
  Settings cfg; Axis ax[N_JOINTS]; Drive drive;
  State state = DISARMED; uint16_t flags = 0; uint8_t hit = 0;

  void begin(uint32_t now);
  void tick(uint32_t now);                    // chamar a 50 Hz
  void onLine(const char* line, uint32_t now);
  void linkDown();                            // BLE caiu
  Pose pose() const { Pose p; for (int i = 0; i < N_JOINTS; i++) p.q[i] = ax[i].q; return p; }
  int lastUs(int i) const { return us[i]; }

 private:
  Hal& hal; uint32_t tLast = 0, tLink = 0, tTel = 0, tBat = 0, tBlock = 0, tArm = 0, tKey = 0, tDrive = 0, tJoy = 0;
  uint32_t mv = 0, lowSince = 0; bool attached[N_SERVOS] = {}, linked = false, loop = false, jogging = false; int us[N_SERVOS] = {};
  uint8_t playSlot = 0, playIdx = 0; float scale = 1.f; Sequence rec, play;

  void reply(const char* f, int a = 0, int b = 0) { char s[64]; snprintf(s, sizeof s, f, a, b); hal.send(s); }
  void ok(char c) { char s[8]; snprintf(s, sizeof s, "K,%c", c); hal.send(s); }
  void err(const char* m) { char s[64]; snprintf(s, sizeof s, "Z,%s", m); hal.send(s); }
  void out(int i, int v) { us[i] = v; hal.servo(i, v); }
  void halt() { drive.stop(); for (auto& a : ax) a.hold(); flags &= ~(F_PLAY); jogging = false; }
  void detachAll() { for (int i = 0; i < N_SERVOS; i++) { attached[i] = false; out(i, 0); } }
  void arm(uint32_t now) { state = ARMED; tArm = now; }
  void motion(uint32_t now, float dt);
  void battery(uint32_t now);
  void telemetry(uint32_t now);
  void sequence(uint32_t now);
  void dumpConfig();
  bool setConfig(const char* k, const char* v);
  void recordCmd(const char* a, uint32_t now);
  static void slotKey(char* d, int s) { snprintf(d, 8, "seq%d", s); }
};

inline void Controller::begin(uint32_t now) {
  Settings t; if (hal.load("cfg", &t, sizeof t) && t.magic == CONFIG_MAGIC && t.version == CONFIG_VERSION) { t.name[16] = 0; cfg = t; }
  for (int i = 0; i < N_JOINTS; i++) ax[i].reset(PRESETS[0].p.q[i]);
  detachAll(); tLast = now; mv = hal.batteryMv(); hal.send("I,BOOT," ESCAV_FW);
}

inline void Controller::linkDown() { linked = false; halt(); flags |= F_LINK; }

inline void Controller::tick(uint32_t now) {
  float dt = (now - tLast) * 0.001f; tLast = now; if (dt > 0.1f) dt = 0.1f;
  if (linked && now - tLink > LINK_TIMEOUT_MS) { linkDown(); err("LINK"); }
  battery(now);
  if (state == ARMED) {
    // comando de joystick sem renovacao para sozinho
    if (now - tDrive > LINK_TIMEOUT_MS) drive.set(0, 0);
    if (jogging && now - tJoy > LINK_TIMEOUT_MS) { for (auto& a : ax) if (!a.position) a.setRate(0); jogging = false; }
    sequence(now); motion(now, dt);
  }
  if (now - tTel >= 100) { tTel = now; telemetry(now); }
}

inline void Controller::motion(uint32_t now, float dt) {
  Pose cur = pose(), nx = cur; float nv[N_JOINTS]; const float s = scale * cfg.armMax * 0.01f;
  for (int i = 0; i < N_JOINTS; i++) nx.q[i] = ax[i].next(JOINTS[i], s, dt, nv[i]);
  flags &= ~F_BLOCK; hit = HIT_NONE;
  if (cfg.guard) {
    const uint8_t c2 = checkPose(cur, 2.f), c0 = c2 ? checkPose(cur, 0.f) : 0; const float m = c2 ? 0.f : 2.f;
    if (!c0 && (hit = checkPose(nx, m)) != HIT_NONE) {   // tenta junta a junta
      flags |= F_BLOCK; Pose acc = cur;
      for (int i = 0; i < N_JOINTS; i++) {
        if (nx.q[i] == cur.q[i]) continue;
        Pose t = acc; t.q[i] = nx.q[i];
        if (checkPose(t, m) == HIT_NONE) acc = t; else { nv[i] = 0; }
      }
      nx = acc;
    }
  }
  bool moving = false;
  for (int i = 0; i < N_JOINTS; i++) { moving |= fabsf(nx.q[i] - cur.q[i]) > 0.001f; ax[i].q = nx.q[i]; ax[i].v = nv[i]; }
  if ((flags & F_BLOCK) && !moving) {
    if (!tBlock) tBlock = now;
    else if (now - tBlock > 1500) { bool pos = false; for (auto& a : ax) pos |= a.position && fabsf(a.target - a.q) > 0.2f; if (pos) { halt(); char e[24]; snprintf(e, sizeof e, "BLOQ,%s", hitName(hit)); err(e); } tBlock = 0; }
  } else tBlock = 0;
  drive.step(dt, scale * cfg.driveMax * 0.01f);
  moving |= fabsf(drive.l) > 0.02f || fabsf(drive.r) > 0.02f;
  flags = moving ? (flags | F_MOVING) : (flags & ~F_MOVING);
  for (int i = 0; i < N_SERVOS; i++) if (!attached[i] && now - tArm >= (uint32_t)i * 150) attached[i] = true;  // partida escalonada
  for (int j = 0; j < N_JOINTS; j++) if (attached[j]) out(j, jointUs(ax[j].q, cfg, j));
  const float w[N_WHEELS] = {drive.l, drive.r, drive.l, drive.r};
  for (int k = 0; k < N_WHEELS; k++) if (attached[N_JOINTS + k]) out(N_JOINTS + k, wheelUs(w[k], cfg, N_JOINTS + k));
}

inline void Controller::battery(uint32_t now) {
  if (now - tBat < 100) return;
  tBat = now; uint32_t r = hal.batteryMv() * cfg.adcCal / 1000; mv = mv ? (mv * 7 + r) / 8 : r;
  flags &= ~(F_WARN | F_NOBAT);
  if (mv < 3000) { flags |= F_NOBAT; lowSince = 0; return; }       // alimentado so pelo USB
  if (mv < cfg.lowMv) flags |= F_WARN;
  if (mv < cfg.cutMv) { if (!lowSince) lowSince = now; else if (now - lowSince > 2000 && state != LOWBAT) { halt(); detachAll(); state = LOWBAT; err("BATERIA"); } }
  else { lowSince = 0; if (state == LOWBAT && mv > cfg.cutMv + 300u) state = DISARMED; }
}

inline void Controller::telemetry(uint32_t now) {
  char s[120]; int q[N_JOINTS]; for (int i = 0; i < N_JOINTS; i++) q[i] = (int)lroundf(ax[i].q * 10);
  snprintf(s, sizeof s, "T,%lu,%d,%d,%d,%lu,%d,%d,%d,%d,%d,%d,%d", (unsigned long)now, state, flags, hit, (unsigned long)mv, q[0], q[1], q[2], q[3],
           (int)lroundf(drive.l * 100), (int)lroundf(drive.r * 100), rec.n);
  hal.send(s);
}

inline void Controller::sequence(uint32_t now) {
  if (!(flags & F_PLAY)) return;
  bool there = true; for (int i = 0; i < N_JOINTS; i++) there &= fabsf(ax[i].target - ax[i].q) < 0.2f;
  if (!there) { tKey = now; return; }
  if (now - tKey < play.k[playIdx].holdMs) return;
  if (++playIdx >= play.n) { if (!loop) { flags &= ~F_PLAY; reply("R,FIM,%d", playSlot); return; } playIdx = 0; }
  for (int i = 0; i < N_JOINTS; i++) ax[i].setTarget(play.k[playIdx].q[i] * 0.1f);
  tKey = now; reply("R,PASSO,%d,%d", playIdx + 1, play.n);
}
}  // namespace escav
// ---- Commands.h
// Protocolo de texto: uma linha por comando, igual no BLE (Nordic UART) e na serial.
namespace escav {
inline int ints(const char* s, int* v, int max) {
  int n = 0;
  while (*s && n < max) { char* e; long x = strtol(s, &e, 10); if (e == s) return -1; v[n++] = (int)x; s = e; if (*s == ',') { s++; if (!*s) return -1; } else if (*s) return -1; }
  return *s ? -1 : n;
}

inline void Controller::dumpConfig() {
  char s[96]; snprintf(s, sizeof s, "C,nome,%s", cfg.name); hal.send(s);
  for (int i = 0; i < N_SERVOS; i++) { snprintf(s, sizeof s, "C,trim%d,%d", i, cfg.trimUs[i]); hal.send(s); snprintf(s, sizeof s, "C,dir%d,%d", i, cfg.dir[i]); hal.send(s); }
  const struct { const char* k; int v; } t[] = {{"usgrau", (int)lroundf(cfg.usPerDeg * 100)}, {"vrodas", cfg.driveMax}, {"vbraco", cfg.armMax}, {"morta", cfg.driveDeadbandUs}, {"guarda", cfg.guard}, {"avisomv", cfg.lowMv}, {"cortemv", cfg.cutMv}, {"adccal", cfg.adcCal}};
  for (auto& x : t) { snprintf(s, sizeof s, "C,%s,%d", x.k, x.v); hal.send(s); }
  for (uint32_t i = 0; i < SEQ_SLOTS; i++) { char k[8]; slotKey(k, i); Sequence q; int n = hal.load(k, &q, sizeof q) && q.n <= SEQ_MAX ? q.n : 0; snprintf(s, sizeof s, "R,SLOT,%lu,%d", (unsigned long)i, n); hal.send(s); }
  hal.send("C,fim,1");
}

inline bool Controller::setConfig(const char* k, const char* v) {
  if (!strcmp(k, "nome")) {
    if (!*v || strlen(v) > 16) return false;
    for (const char* c = v; *c; c++) if (*c < 32 || *c == ',' || (unsigned char)*c > 126) return false;
    strcpy(cfg.name, v); return true;
  }
  char* e; long x = strtol(v, &e, 10); if (e == v || *e) return false;
  auto in = [&](long a, long b) { return x >= a && x <= b; };
  if (!strncmp(k, "trim", 4)) { int i = k[4] - '0'; if (i < 0 || i >= N_SERVOS || k[5] || !in(-400, 400)) return false; cfg.trimUs[i] = x; return true; }
  if (!strncmp(k, "dir", 3)) { int i = k[3] - '0'; if (i < 0 || i >= N_SERVOS || k[4] || (x != 1 && x != -1)) return false; cfg.dir[i] = x; return true; }
  if (!strcmp(k, "usgrau")) { if (!in(800, 1200)) return false; cfg.usPerDeg = x * 0.01f; return true; }
  if (!strcmp(k, "vrodas")) { if (!in(10, 100)) return false; cfg.driveMax = x; return true; }
  if (!strcmp(k, "vbraco")) { if (!in(10, 100)) return false; cfg.armMax = x; return true; }
  if (!strcmp(k, "morta")) { if (!in(0, 200)) return false; cfg.driveDeadbandUs = x; return true; }
  if (!strcmp(k, "guarda")) { if (!in(0, 1)) return false; cfg.guard = x; return true; }
  if (!strcmp(k, "avisomv")) { if (!in(6000, 8400)) return false; cfg.lowMv = x; return true; }
  if (!strcmp(k, "cortemv")) { if (!in(5500, 8000)) return false; cfg.cutMv = x; return true; }
  if (!strcmp(k, "adccal")) { if (!in(800, 1200)) return false; cfg.adcCal = x; return true; }
  return false;
}

// R,0 limpa | R,1,ms ponto | R,2,slot salva | R,3,slot,loop toca | R,4 para | R,5,slot apaga | R,6 desfaz
inline void Controller::recordCmd(const char* a, uint32_t now) {
  int v[3] = {0, 0, 0}; int n = ints(a, v, 3); if (n < 1) return err("FORMATO");
  char k[8]; const bool slotOk = v[1] >= 0 && v[1] < (int)SEQ_SLOTS;
  switch (v[0]) {
    case 0: rec.n = 0; flags |= F_REC; break;
    case 1:
      if (rec.n >= SEQ_MAX) return err("CHEIO");
      for (int i = 0; i < N_JOINTS; i++) rec.k[rec.n].q[i] = (int16_t)lroundf(ax[i].q * 10);
      rec.k[rec.n].holdMs = (uint16_t)clampf(n > 1 ? v[1] : 0, 0, 10000); rec.n++; flags |= F_REC; break;
    case 2: if (!slotOk || !rec.n) return err("SLOT"); slotKey(k, v[1]); if (!hal.save(k, &rec, sizeof rec)) return err("GRAVAR"); flags &= ~F_REC; reply("R,SLOT,%d,%d", v[1], rec.n); break;
    case 3:
      if (state != ARMED) return err("DESARMADA");
      if (!slotOk) return err("SLOT");
      slotKey(k, v[1]); if (!hal.load(k, &play, sizeof play) || !play.n || play.n > SEQ_MAX) return err("VAZIO");
      playSlot = v[1]; playIdx = 0; loop = n > 2 && v[2]; flags |= F_PLAY; tKey = now; jogging = false;
      for (int i = 0; i < N_JOINTS; i++) ax[i].setTarget(clampf(play.k[0].q[i] * 0.1f, JOINTS[i].min, JOINTS[i].max));
      break;
    case 4: if (flags & F_PLAY) halt(); break;
    case 5: { if (!slotOk) return err("SLOT"); Sequence z; slotKey(k, v[1]); hal.save(k, &z, sizeof z); reply("R,SLOT,%d,%d", v[1], 0); break; }
    case 6: if (rec.n) rec.n--; break;
    default: return err("FORMATO");
  }
  ok('R');
}
}  // namespace escav
// ---- OnLine.h
namespace escav {
inline void Controller::onLine(const char* s, uint32_t now) {
  while (*s == ' ') s++;
  if (!*s) return;
  tLink = now; linked = true; flags &= ~F_LINK;
  const char c = s[0]; if (s[1] && s[1] != ',') return err("COMANDO");
  const char* a = s[1] ? s + 2 : s + 1; int v[4];
  switch (c) {
    case 'H': { char b[96]; snprintf(b, sizeof b, "I,ESCAV,%s,%s,%d", ESCAV_FW, cfg.name, N_PRESETS); hal.send(b); break; }
    case 'P': { char b[40]; snprintf(b, sizeof b, "O,%.24s", a); hal.send(b); break; }
    case 'S': halt(); detachAll(); if (state != LOWBAT) state = ESTOP; err("PARADA"); break;
    case 'U': if (state == LOWBAT) return err("BATERIA"); if (state != ARMED) { halt(); arm(now); } ok('U'); break;
    case 'M': halt(); detachAll(); if (state != LOWBAT) state = DISARMED; ok('M'); break;
    case 'D':
      if (ints(a, v, 2) != 2) return err("FORMATO");
      if (state != ARMED) return;
      drive.set(v[0] * .01f, v[1] * .01f); tDrive = now; break;
    case 'J': {
      if (ints(a, v, 4) != 4) return err("FORMATO");
      if (state != ARMED) return;
      const bool any = v[0] | v[1] | v[2] | v[3];
      if (!any && !jogging) return;                 // joystick parado nao cancela preset nem sequencia
      flags &= ~F_PLAY; jogging = any; tJoy = now;
      for (int i = 0; i < N_JOINTS; i++) ax[i].setRate(clampf(v[i] * .01f, -1, 1));
      break; }
    case 'A': case 'G': {
      Pose p;
      if (c == 'A') { if (ints(a, v, 4) != 4) return err("FORMATO"); for (int i = 0; i < N_JOINTS; i++) p.q[i] = clampf(v[i] * .1f, JOINTS[i].min, JOINTS[i].max); }
      else { if (ints(a, v, 1) != 1 || v[0] < 0 || v[0] >= N_PRESETS) return err("FORMATO"); p = PRESETS[v[0]].p; p.q[SLEW] = ax[SLEW].q; }
      if (state != ARMED) return err("DESARMADA");
      if (cfg.guard) { uint8_t h = checkPose(p, 2.f); if (h) { char b[24]; snprintf(b, sizeof b, "BLOQ,%s", hitName(h)); return err(b); } }
      flags &= ~F_PLAY; jogging = false; for (int i = 0; i < N_JOINTS; i++) ax[i].setTarget(p.q[i]);
      ok(c); break; }
    case 'V': if (ints(a, v, 1) != 1 || v[0] < 10 || v[0] > 100) return err("FORMATO"); scale = v[0] * .01f; ok('V'); break;
    case 'R': recordCmd(a, now); break;
    case 'Q': dumpConfig(); break;
    case 'C': {
      char b[48]; strncpy(b, a, sizeof b - 1); b[sizeof b - 1] = 0; char* m = strchr(b, ','); if (!m) return err("FORMATO");
      *m = 0; if (!setConfig(b, m + 1)) return err("VALOR");
      flags |= F_DIRTY; ok('C'); break; }
    case 'W': if (!hal.save("cfg", &cfg, sizeof cfg)) return err("GRAVAR"); flags &= ~F_DIRTY; ok('W'); break;
    case 'X': cfg = Settings(); hal.save("cfg", &cfg, sizeof cfg); flags &= ~F_DIRTY; ok('X'); break;
    default: err("COMANDO");
  }
}
}  // namespace escav



#ifndef SEM_BLE
#include <NimBLEDevice.h>
#endif
#if ESP_ARDUINO_VERSION_MAJOR >= 3   // core 3.x: a API do LEDC passou a ser por pino
static uint8_t canalPino[16]; static uint32_t canalHz[16]; static uint8_t canalBits[16];
static inline void webSetup(uint8_t c, uint32_t hz, uint8_t bits) { canalHz[c] = hz; canalBits[c] = bits; if (canalPino[c]) ledcChangeFrequency(canalPino[c], hz, bits); }
static inline void webAttach(uint8_t p, uint8_t c) { canalPino[c] = p; ledcAttachChannel(p, canalHz[c], canalBits[c], c); }
static inline void webWrite(uint8_t c, uint32_t d) { if (canalPino[c]) ledcWrite(canalPino[c], d); }
#define ledcSetup webSetup
#define ledcAttachPin webAttach
#define ledcWrite webWrite
#endif
using namespace escav;

//                              giro lanca braco cacamba  FE  FD  TE  TD
constexpr uint8_t PIN_SERVO[N_SERVOS] = {21, 22, 23, 25, 16, 17, 18, 19};
constexpr uint8_t PIN_BAT = 34;
// LEDC: canais 2k e 2k+1 dividem timer. Servos 0..7 (4 timers de 50 Hz, grupo alto).
constexpr int SERVO_BITS = 16;
constexpr float DIV_BAT = (100.f + 47.f) / 47.f;   // divisor 100k / 47k

struct Line { char s[64]; };
static QueueHandle_t rxq;
struct Assembler {
  char b[64]; uint8_t n = 0; bool drop = false;
  void feed(char c) {
    if (c == '\r') return;
    if (c == '\n') { if (!drop && n) { Line l; memcpy(l.s, b, n); l.s[n] = 0; xQueueSend(rxq, &l, 0); } n = 0; drop = false; }
    else if (n < 63) b[n++] = c; else drop = true;
  }
  void clear() { n = 0; drop = false; }
};
static Assembler asSerial, asBle;
static volatile bool bleDown = false, bleUp = false;

#ifndef SEM_BLE
static NimBLECharacteristic* tx = nullptr;
static volatile uint16_t bleMtu = 23;
struct SrvCb : NimBLEServerCallbacks {
  void onConnect(NimBLEServer* s, ble_gap_conn_desc* d) override { bleMtu = 23; asBle.clear(); bleUp = true; s->updateConnParams(d->conn_handle, 12, 24, 0, 200); }
  void onDisconnect(NimBLEServer*) override { bleUp = false; bleDown = true; NimBLEDevice::startAdvertising(); }
  void onMTUChange(uint16_t m, ble_gap_conn_desc*) override { bleMtu = m; }
};
struct RxCb : NimBLECharacteristicCallbacks {
  void onWrite(NimBLECharacteristic* c) override { std::string v = c->getValue(); for (char x : v) asBle.feed(x); }
};
static void bleBegin(const char* name) {
  NimBLEDevice::init(name); NimBLEDevice::setMTU(185); NimBLEDevice::setPower(ESP_PWR_LVL_P9);
  auto* srv = NimBLEDevice::createServer(); srv->setCallbacks(new SrvCb());
  auto* s = srv->createService("6E400001-B5A3-F393-E0A9-E50E24DCCA9E");
  tx = s->createCharacteristic("6E400003-B5A3-F393-E0A9-E50E24DCCA9E", NIMBLE_PROPERTY::NOTIFY);
  auto* rx = s->createCharacteristic("6E400002-B5A3-F393-E0A9-E50E24DCCA9E", NIMBLE_PROPERTY::WRITE | NIMBLE_PROPERTY::WRITE_NR);
  rx->setCallbacks(new RxCb()); s->start();
  auto* a = NimBLEDevice::getAdvertising(); a->addServiceUUID(s->getUUID()); a->setScanResponse(true); NimBLEDevice::startAdvertising();
}
#endif
// ---- esp_hal.h
// Incluido por main.cpp: implementacao do Hal + setup/loop.
class Esp : public Hal {
  Preferences nvs;
  char ring[4096]; size_t head = 0, used = 0;       // saida BLE ritmada: nao perde linhas em rajada
 public:
  void flushBle() {
#ifndef SEM_BLE
    if (!bleUp) { head = used = 0; return; }
    static uint32_t t = 0; if (!tx || !used || millis() - t < 8) return;
    t = millis(); uint8_t b[182]; size_t m = bleMtu > 23 ? bleMtu - 3 : 20, n = 0; if (m > sizeof b) m = sizeof b;
    while (n < m && used) { b[n++] = ring[head]; head = (head + 1) % sizeof ring; used--; }
    tx->setValue(b, n); tx->notify();
#endif
  }
  void begin() {
    nvs.begin("escav", false); analogSetPinAttenuation(PIN_BAT, ADC_11db);
    for (int i = 0; i < N_SERVOS; i++) { ledcSetup(i, 50, SERVO_BITS); ledcAttachPin(PIN_SERVO[i], i); ledcWrite(i, 0); }
  }
  // duty 0 corta o pulso; no pior caso o ultimo pulso sai encurtado uma vez (medido no analisador logico do Wokwi)
  void pulso(int i, int us) { ledcWrite(i, us ? (uint32_t)((uint64_t)us * 65536 / 20000) : 0); }
#if defined(DIGITADO) && RODA_VISUAL
  // So no site: o servo do Wokwi nao gira 360 graus. A cruz e igual a cada 90 graus, entao varrer 90 e saltar parece girar.
  int rodaUs[N_WHEELS] = {}; float rodaAng[N_WHEELS] = {};
  void servo(int i, int us) override { if (i < N_JOINTS) pulso(i, us); else rodaUs[i - N_JOINTS] = us; }
  void rodas() {
    static uint32_t t = millis(); uint32_t n = millis(); if (n - t < 20) return; float dt = (n - t) * .001f; t = n;
    for (int w = 0; w < N_WHEELS; w++) {
      if (rodaUs[w]) rodaAng[w] = fmodf(rodaAng[w] + (rodaUs[w] - 1500) / 500.f * 600.f * dt + 90.f, 90.f);   // SG90 360: 600 graus/s no maximo
      pulso(N_JOINTS + w, rodaUs[w] ? (int)(1008 + rodaAng[w] * 10.31f) : 0);
    }
  }
#else
  void servo(int i, int us) override { pulso(i, us); }
#endif
  uint32_t batteryMv() override { return (uint32_t)(analogReadMilliVolts(PIN_BAT) * DIV_BAT); }
  bool load(const char* k, void* d, size_t n) override { return nvs.isKey(k) && nvs.getBytesLength(k) == n && nvs.getBytes(k, d, n) == n; }
  bool save(const char* k, const void* s, size_t n) override { return nvs.putBytes(k, s, n) == n; }
  void send(const char* l) override {
#ifdef DIGITADO   // so no site do Wokwi: esconde o eco do ping e repete a telemetria apenas quando muda
    static char antes[128] = "";
    if (!strcmp(l, "O,0")) return;
    if (l[0] == 'T') { const char* c = strchr(l + 2, ','); if (!c || !strcmp(c, antes)) return; strncpy(antes, c, sizeof antes - 1); }
#endif
    Serial.println(l);
#ifndef SEM_BLE
    if (!bleUp) return;
    size_t n = strlen(l); if (used + n + 1 > sizeof ring) return;      // cheio: descarta a linha inteira
    for (size_t i = 0; i <= n; i++) { ring[(head + used) % sizeof ring] = i < n ? l[i] : char(10); used++; }
#endif
  }
};
static Esp hal;
static Controller ctl(hal);

inline void escavSetup() {
  Serial.begin(115200); rxq = xQueueCreate(24, sizeof(Line)); hal.begin(); ctl.begin(millis());
#ifndef SEM_BLE
  bleBegin(ctl.cfg.name);
#endif
  Serial.println("PRONTO");
}

inline void escavLoop() {
  static uint32_t next = millis();
  while (Serial.available()) asSerial.feed((char)Serial.read());
  if (bleDown) { bleDown = false; asBle.clear(); ctl.linkDown(); }
#ifdef DIGITADO   // quem digita nao manda ping: mantem o sinal vivo para o braco terminar o movimento
  static uint32_t ping = 0; static char repD[64] = "", repJ[64] = "";   // D e J valem ate D,0,0 / J,0,0,0,0 / S
  if (millis() - ping > 200) { ping = millis(); ctl.onLine("P,0", millis()); if (*repD) ctl.onLine(repD, millis()); if (*repJ) ctl.onLine(repJ, millis()); }
#if RODA_VISUAL
  hal.rodas();
#endif
#endif
  Line l; while (xQueueReceive(rxq, &l, 0) == pdTRUE) {
#ifdef DIGITADO
    if (l.s[0] == '?') { Serial.print(AJUDA); continue; }
    if (l.s[0] == 'D') strcpy(repD, strcmp(l.s, "D,0,0") ? l.s : "");
    if (l.s[0] == 'J') strcpy(repJ, strcmp(l.s, "J,0,0,0,0") ? l.s : "");
    if (strchr("SMUX", l.s[0])) *repD = 0;
    if (strchr("SMUXAGR", l.s[0])) *repJ = 0;
#endif
    ctl.onLine(l.s, millis());
  }
  uint32_t now = millis();
  if ((int32_t)(now - next) >= 0) { next += 20; if ((int32_t)(now - next) > 100) next = now + 20; ctl.tick(now); }
  hal.flushBle();
  delay(1);
}

