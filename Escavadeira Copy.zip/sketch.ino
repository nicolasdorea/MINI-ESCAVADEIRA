// Escavadeira ESP32: simulacao no Wokwi. Gerado por gera_web.py a partir de firmware/src e comandos.txt.
// Aperte PLAY e digite no Serial Monitor, uma linha por vez, com Enter:
//
//  ===== LIGAR E PARAR =====
//  ?                    mostra esta lista
//  U                    arma (libera os motores)
//  M                    desarma (solta os motores)
//  S                    parada de emergencia (U para rearmar)
//  ===== MOVER (precisa armar com U) =====
//  A,g,l,b,c            angulos em decimos de grau: A,450,-200,-350,-200
//                       giro -900..900, lanca -850..500, braco -1300..350, cacamba -900..900
//  G,n                  pose: 0 transporte, 1 trabalho, 2 cavar, 3 carregar, 4 despejar, 5 alcance
//  D,frente,curva       rodas, -100..100 cada. D,60,0 frente  D,-60,0 re  D,0,50 gira direita  D,0,0 para
//  J,g,l,b,c            manche, -100..100 cada. J,50,0,0,0 gira  J,0,0,0,0 para
//                       (no site, D e J continuam ate mandar parar. Na maquina real,
//                       param 0,6 s depois do ultimo comando: o app repete enquanto voce segura)
//  V,n                  velocidade geral, 10..100
//  ===== SEQUENCIAS =====
//  R,0                  comeca gravacao nova
//  R,1,ms               marca a pose atual e a espera (0..10000 ms), ate 24 pontos
//  R,6                  desfaz o ultimo ponto
//  R,2,m                salva na memoria m (0 a 2)
//  R,3,m,0              toca a memoria m uma vez
//  R,3,m,1              toca a memoria m sem parar
//  R,4                  interrompe
//  R,5,m                apaga a memoria m
//  ===== CONSULTAR =====
//  H                    nome e versao
//  P,texto              teste de resposta: devolve O,texto
//  Q                    mostra todos os ajustes e memorias
//  ===== AJUSTAR (C,chave,valor e depois W) =====
//  W                    grava os ajustes
//  X                    volta aos ajustes de fabrica (as sequencias ficam)
//  C,nome,texto         nome no Bluetooth, ate 16 letras sem acento
//  C,trim0..7,us        centro do servo, -400..400
//  C,dir0..7,1 ou -1    sentido do servo
//                       0 giro 1 lanca 2 braco 3 cacamba 4 roda FE 5 FD 6 TE 7 TD
//  C,vrodas,n           velocidade maxima das rodas, 10..100
//  C,vbraco,n           velocidade maxima do braco, 10..100
//  C,guarda,0 ou 1      anticolisao desligada ou ligada
//  C,morta,n            zona morta das rodas em us, 0..200
//  C,usgrau,n           pulso por grau x100, 800..1200
//  C,avisomv,n          aviso de bateria em mV, 6000..8400
//  C,cortemv,n          corte de bateria em mV, 5500..8000
//  C,adccal,n           correcao da leitura da bateria, 800..1200
//  ===== RESPOSTAS =====
//  K,x ok   O,x resposta do P   I identificacao   C ajuste   R sequencia   Z,motivo recusado
//  Z: COMANDO FORMATO VALOR DESARMADA PARADA BATERIA LINK VAZIO CHEIO SLOT GRAVAR BLOQ (anticolisao)
//  T,ms,estado,avisos,colisao,mV,giro,lanca,braco,cacamba,rodaE,rodaD,pontos

#define SEM_BLE 1   // o Wokwi nao simula Bluetooth: mesmos comandos pela serial
#define DIGITADO 1  // comandos digitados a mao: sem parada por falta de sinal e sem repetir telemetria igual
#define RODA_VISUAL 1  // 1 = rodas aparecem girando (efeito visual; o servo do Wokwi nao gira 360). 0 = pulso real
static const char AJUDA[] = R"AJ(
===== LIGAR E PARAR =====
?                    mostra esta lista
U                    arma (libera os motores)
M                    desarma (solta os motores)
S                    parada de emergencia (U para rearmar)
===== MOVER (precisa armar com U) =====
A,g,l,b,c            angulos em decimos de grau: A,450,-200,-350,-200
                     giro -900..900, lanca -850..500, braco -1300..350, cacamba -900..900
G,n                  pose: 0 transporte, 1 trabalho, 2 cavar, 3 carregar, 4 despejar, 5 alcance
D,frente,curva       rodas, -100..100 cada. D,60,0 frente  D,-60,0 re  D,0,50 gira direita  D,0,0 para
J,g,l,b,c            manche, -100..100 cada. J,50,0,0,0 gira  J,0,0,0,0 para
                     (no site, D e J continuam ate mandar parar. Na maquina real,
                     param 0,6 s depois do ultimo comando: o app repete enquanto voce segura)
V,n                  velocidade geral, 10..100
===== SEQUENCIAS =====
R,0                  comeca gravacao nova
R,1,ms               marca a pose atual e a espera (0..10000 ms), ate 24 pontos
R,6                  desfaz o ultimo ponto
R,2,m                salva na memoria m (0 a 2)
R,3,m,0              toca a memoria m uma vez
R,3,m,1              toca a memoria m sem parar
R,4                  interrompe
R,5,m                apaga a memoria m
===== CONSULTAR =====
H                    nome e versao
P,texto              teste de resposta: devolve O,texto
Q                    mostra todos os ajustes e memorias
===== AJUSTAR (C,chave,valor e depois W) =====
W                    grava os ajustes
X                    volta aos ajustes de fabrica (as sequencias ficam)
C,nome,texto         nome no Bluetooth, ate 16 letras sem acento
C,trim0..7,us        centro do servo, -400..400
C,dir0..7,1 ou -1    sentido do servo
                     0 giro 1 lanca 2 braco 3 cacamba 4 roda FE 5 FD 6 TE 7 TD
C,vrodas,n           velocidade maxima das rodas, 10..100
C,vbraco,n           velocidade maxima do braco, 10..100
C,guarda,0 ou 1      anticolisao desligada ou ligada
C,morta,n            zona morta das rodas em us, 0..200
C,usgrau,n           pulso por grau x100, 800..1200
C,avisomv,n          aviso de bateria em mV, 6000..8400
C,cortemv,n          corte de bateria em mV, 5500..8000
C,adccal,n           correcao da leitura da bateria, 800..1200
===== RESPOSTAS =====
K,x ok   O,x resposta do P   I identificacao   C ajuste   R sequencia   Z,motivo recusado
Z: COMANDO FORMATO VALOR DESARMADA PARADA BATERIA LINK VAZIO CHEIO SLOT GRAVAR BLOQ (anticolisao)
T,ms,estado,avisos,colisao,mV,giro,lanca,braco,cacamba,rodaE,rodaD,pontos
)AJ";
#include "escavadeira.h"
void setup() { escavSetup(); Serial.println("Digite ? para ver todos os comandos"); }
void loop() { escavLoop(); }
